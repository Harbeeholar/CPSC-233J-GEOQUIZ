package com.example.geoquizapp1m

class Utils {
    companion object{
        var q1Answer: Boolean = false
        var q2Answer: Boolean = false
        var q3Answer: Boolean = false
        var q4Answer: Boolean = false
    }
}